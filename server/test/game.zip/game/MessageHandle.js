var util = require("util");

var MessageHandle = function()
{

    this.test = function()
    {
        util.log("MessageHandle: test:");
    };

   
};


exports.Class = MessageHandle;

